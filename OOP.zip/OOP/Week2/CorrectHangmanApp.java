/*
 *HangmanApp.java
 *@author J. Power
 *27th Jan 2014
 */
import javax.swing.JOptionPane;
public class CorrectHangmanApp{
	public static void main(String args[]){
		String input, secret, result;
		char guess;

		CorrectHangman myCorrectHangman = new CorrectHangman();

		//input
		input = JOptionPane.showInputDialog(null, "Please enter a letter");
		guess = input.charAt(0);

		//process
		myCorrectHangman.setGuess(guess);
		myCorrectHangman.compute();
		result = myCorrectHangman.getResult();
		secret = myCorrectHangman.getSecret();

		//output
		JOptionPane.showMessageDialog(null, "The result is " + result);
		JOptionPane.showMessageDialog(null, "The secret word was " + secret);
	}
}