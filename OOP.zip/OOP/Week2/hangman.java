public class hangman{


		//data members
		private String secretWord;
		private String word;
		private int lives;
	    boolean validity;
	    private StringBuffer strBuff;

		//constructor
		public hangman(){
			String secretWord = "";
			String newword= "";
			int lives = 10;
			strBuff=new StringBuffer();


		}

		//setters
		public void setSecretWord(String secretWord){
			this.secretWord=secretWord;
		}


		//compute

		public void compute(){
			secretWord="java";
			for(int i=0;i<secretWord.length();i++){
				if(secretWord.charAt(i)==guess){
				strBuff.append(secretWord.charAt(i));
					System.out.print("*");
				}
				else{
					strBuff.append('*');
				}
			}
			newSecretWord=strBuff.toString();
			displayWord=newSecretWord;

		}
		//getters
		public String getSecretWord(){
			return secretWord;
		}
		public String getNewWord(){
				return secretWord;
		}


}