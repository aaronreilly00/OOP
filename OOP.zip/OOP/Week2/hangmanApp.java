

import javax.swing.*;
public class hangmanApp{
	public static void main(String args[]){

		//variables
		String secretWord;
		String word;
		int lives;
		char guess;


			//object
		hangman myhangman=new hangman();
			//input
		secretWord=JOptionPane.showInputDialog(null, "Please guess a letter ");
		myhangman.setSecretWord(secretWord);


		//process
		myhangman.compute();


		//output
		secretWord=myhangman.getSecretWord();
		JOptionPane.showMessageDialog(null, "Your secret word is "+secretWord);

	}


}