/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author x17124719
 */
public class Persons {
    
    public String name;
    public int age;
    
    public Persons(){
        String inName = "bob" ;
        int inAge = 9;
        
    }  
    public void setName(String inName){
        this.name=inName;
    }
    public void setAge(int inAge){
        this.age=inAge;
    }
    
    public String getName(){
       return name; 
    }
    public int getAge(){
        return age;
    }
    public void printPerson(){
        System.out.println("name is " + name + "age is" + age);
    }
  }

