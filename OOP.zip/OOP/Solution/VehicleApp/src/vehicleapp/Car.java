/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicleapp;

/**
 *
 * @author sofiane
 */
public class Car extends Vehicle {
    
    private double topSpeed; 
    private double fuelConsumption;
    
    public Car(String regNum, String Type, int numWheels, int numSeats, double topSpeed, double fuelConsumption){
        super(regNum, Type, numWheels, numSeats);
        this.topSpeed = topSpeed; 
        this.fuelConsumption = fuelConsumption; 
    }
    
    public Car(){
        this("", "", 0, 0, 0, 0);    
    }
    
    public void setTopSpeed(double topSpeed){
        this.topSpeed = topSpeed; 
    }
    
    public void setFuelConsumption(double fuelConsumption){
        this.fuelConsumption = fuelConsumption; 
    }
    
    public double getTopSpeed(){
        return topSpeed;
    }
    
    public double getFuelConsumption(){
        return fuelConsumption; 
    }
    
    @Override
    public String printDetails(){
        return super.printDetails()+" Top speed "+topSpeed+
                " Fuel consumption "+fuelConsumption;
    }    
}
