/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicleapp;

import java.io.Serializable;

/**
 *
 * @author sofiane
 */
public class Vehicle implements Serializable{
    
    protected String regNum; 
    protected String Type; 
    protected int numWheels; 
    protected int numSeats; 
    
    public Vehicle(String regNum, String Type, int numWheels, int numSeats){
        this.regNum = regNum; 
        this.Type = Type;
        this. numWheels = numWheels; 
        this.numSeats = numSeats; 
    }
    
    public Vehicle(){
        this("", "", 0, 0); 
    }    
    
    public void setRegNum (String regNum){
        this.regNum = regNum; 
    }
    
    public void setType(String Type){
        this.Type = Type; 
    }
    
    public void setNumWheels(int numWheels){
        this.numWheels = numWheels; 
    }
    
    public void setNumSeats(int numSeats){
        this.numSeats = numSeats; 
    }
    
    public String getRegNum(){
        return regNum;
    }
    
    public String getType(){
        return Type;
    }
    
    public int getNumWheels(){
        return numWheels;
    }
    
    public int getNumSeats(){
        return numSeats;
    }
    
    public String printDetails(){
        return "Registration Number "+regNum+" Type of vehicle "+Type+
                " Number of wheels "+numWheels+" Number of seats "+ numSeats;
    }
}
