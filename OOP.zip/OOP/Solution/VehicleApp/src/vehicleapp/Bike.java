/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicleapp;

/**
 *
 * @author sofiane
 */
public class Bike extends Vehicle {
    
    private double topSpeed; 
    private double stabFact;
    
    public Bike(String regNum, String Type, int numWheels, int numSeats, double topSpeed, double stabFact){
        super(regNum, Type, numWheels, numSeats);
        this.topSpeed = topSpeed; 
        this.stabFact = stabFact;
    }
    
    public Bike(){
        this("", "", 0, 0, 0, 0);
    }
    
    public void setTopSpeed(double topSpeed){
        this.topSpeed = topSpeed; 
    }
    
    public void setStabFact(double stabFact){
        this.stabFact = stabFact; 
    }
    
    public double getTopSpeed(){
        return topSpeed;
    }
    
    public double getStabFact(){
        return stabFact; 
    }
    
    @Override
    public String printDetails(){
        return super.printDetails()+" Top speed "+topSpeed+
                " Stability Factor "+stabFact;
    }  
}
