/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicleapp;

/**
 *
 * @author sofiane
 */
public class Bus extends Vehicle {
    
    private double fuelConsumption; 
    private int standingCapacity;
    
    public Bus(String regNum, String Type, int numWheels, int numSeats, 
            double fuelConsumption, int standingCapacity){
        super(regNum, Type, numWheels, numSeats);
        this.fuelConsumption = fuelConsumption; 
        this.standingCapacity = standingCapacity; 
    }
    
    public Bus(){
        this("", "", 0, 0, 0, 0);    
    }
    
        
    public double getFuelConsumption(){
        return fuelConsumption; 
    }
    
    public double getStandingCapacity(){
        return standingCapacity;
    }
    
    public void setFuelConsumption(double fuelConsumption){
        this.fuelConsumption = fuelConsumption; 
    }
    
    public void setStandingCapacity(int standingCapacity){
        this.standingCapacity = standingCapacity; 
    }
    
    @Override
    public String printDetails(){
        return super.printDetails()+" Fuel consumption "+fuelConsumption+
                " Standing capacity "+standingCapacity;
    }    
}
