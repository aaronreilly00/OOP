/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moduleapp;

/**
 *
 * @author x17124719
 */
public class Technical extends Module{
    protected String labDay;

    public Technical(String name, String lecturer, String lectureDay, String labDay) {
        super(name, lecturer, lectureDay);
        this.labDay = labDay;
    }
    public Technical(){
        this("","","","");
    }

    public void setLabDay(String labDay) {
        this.labDay = labDay;
    }

    public String getLabDay() {
        return labDay;
    }
    @Override
    public String printDetails(){
        return super.printDetails()+" Lab Day"+labDay;
    }
}
