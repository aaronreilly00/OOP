/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moduleapp;

/**
 *
 * @author x17124719
 */
public class Business extends Module {
    
    private String tutorialDay;

    public Business(String name, String lecturer, String lectureDay,String tutorialDay) {
        super(name, lecturer, lectureDay);
        this.tutorialDay = tutorialDay;
    }
    public Business(){
        this("", "","","");
    }

    public void setTutorialDay(String tutorialDay) {
        this.tutorialDay = tutorialDay;
    }

    public String getTutorialDay() {
        return tutorialDay;
    }
    @Override
    public String printDetails(){
        return super.printDetails()+" tutorial day "+tutorialDay;
    }
    
}
