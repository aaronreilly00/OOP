/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moduleapp;

import java.io.Serializable;

/**
 *
 * @author x17124719
 */
public class Module implements Serializable{
    
    protected String name;
    protected String lecturer;
    protected String lectureDay;
    
    
    
    public Module(String name, String lecturer, String lectureDay){
        this.name=name;
        this.lecturer=lecturer;
        this.lectureDay=lectureDay;
        
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLecturer(String lecturer) {
        this.lecturer = lecturer;
    }

    public void setLectureDay(String lectureDay) {
        this.lectureDay = lectureDay;
    }

    
    public String getName() {
        return name;
    }

    public String getLecturer() {
        return lecturer;
    }

    public String getLectureDay() {
        return lectureDay;
    }

    public String printDetails(){
        return " name "+name+" lecturer "+lecturer+" Lecture Day"+lectureDay;
    }
}
