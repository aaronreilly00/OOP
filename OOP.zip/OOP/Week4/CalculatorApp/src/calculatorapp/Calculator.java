/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculatorapp;

/**
 *
 * @author x17124719
 */
import java.awt.Color;
import javax.swing.*;
public class Calculator extends JFrame {
   //declare objects
    private JPanel p;
    private JLabel num1;
    private JLabel num2;
    private JTextField num1Jtf;
    private JTextField num2Jtf;
    private JButton addBtn;
    private JButton mulBtn;
    private int total;
    public Calculator(){
        
        setSize(500, 250); //set size of JFrame
        setLocation(10,10); //set Location of JFrame on Screen
        p = new JPanel(); //create new panel 
        p.setLayout(null);//set layout of panel
        p.setBackground(Color.RED);
        add(p);
        
        num1 = new JLabel("Enter number 1:");
        num2 = new JLabel("Enter number 2:");
        
        num1Jtf = new JTextField();
        num2Jtf = new JTextField();
        
        addBtn = new JButton("Add");
        mulBtn = new JButton("Multiply");
            
        num1.setBounds(10,10,200,30); //x,y,width,height
        num2.setBounds(10,50,200,30);
        
        num1Jtf.setBounds(230,10,200,30);
        num2Jtf.setBounds(230,50,200,30);
        
        addBtn.setBounds(10,100,200,30);
        mulBtn.setBounds(230,100,200,30);
        
        p.add(num1);
        p.add(num2);
        
        p.add(num1Jtf);
        p.add(num2Jtf);
        
        p.add(addBtn);
        p.add(mulBtn);
        
        
        
    }
    public int addBtn(){
        int num1 = 0;
        int num2 = 0;
        
        num1=Integer.parseInt(JOptionPane.showInputDialog(null,"Please enter first number"+num1));
        num2=Integer.parseInt(JOptionPane.showInputDialog(null,"Please enter first number"+num2));
        
        public void compute(){
            total = num1Jtf+num2Jtf;
        }
        public int getTotal(){
            return total;
        }
    }
    
    
    
    
    
}
