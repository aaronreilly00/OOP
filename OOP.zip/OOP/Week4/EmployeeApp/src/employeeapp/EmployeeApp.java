/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeapp;

/**
 *
 * @author room3.03
 */
public class EmployeeApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //using default constructor
        Employee e = new Employee();
        e.setDob("12/12/1963");
        e.setId("00000");
        e.setName("J Bloggs");
        //System.out.println("Employee details:"+e.getDob()+","+e.getId()+","+e.getName());
        //e.printDetails();
        System.out.println(e.printDetails());
        
        //overloaded constructor
        Employee e1 = new Employee("e001", "Bob","11/11/61");
        System.out.println("Employee details:"+e1.getDob()+","+e1.getId()+","+e1.getName());
        
        //manager with default constructor
        Manager m = new Manager();
        m.setId("m001");
        m.setName("John");
        m.setDob("01/01/72");
        m.setSalary(80000);
        //System.out.println("Manager Details:"+m.getId()+","+m.getDob()+","+m.getName()+","+m.getSalary());
        System.out.println(m.printDetails());
        //manager with overloaded constructor
        Manager m1 = new Manager(76000,"m002","Mary","21/05/80");
        System.out.println("Manager Details:"+m1.getId()+","+m1.getDob()+","+m1.getName()+","+m1.getSalary());
        
        //Floor staff with overloaded constructor
        FloorStaff f1 = new FloorStaff(15,"f001","Jane","20/20/96");
        System.out.println("Floor Staff Details:"+f1.getId()+","+f1.getDob()+","+f1.getName()+","+f1.getRate());

        //give Jane a payrise
        f1.setRate(20);
        System.out.println("Floor Staff Details:"+f1.getId()+","+f1.getDob()+","+f1.getName()+","+f1.getRate());

        
        
        
        
    }
    
}
