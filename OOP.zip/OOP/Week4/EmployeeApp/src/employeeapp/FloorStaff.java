/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeapp;

/**
 *
 * @author room3.03
 */
public class FloorStaff extends Employee{
    private double rate;

    public FloorStaff(double rate, String id, String name, String dob) {
        super(id, name, dob);
        this.rate = rate;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
    
    //add printDetails method
    
}
