/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeeapp;

/**
 *
 * @author room3.03
 */
public class Manager extends Employee {
    private double salary;

    public Manager(double salary, String id, String name, String dob) {
        super(id, name, dob);
        this.salary = salary;
    }
    
    public Manager(){
        id = " ";
        name = " ";
        dob = " ";
        salary = 0;
    }
  

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    //annotation for javadoc regarding overiding methods
    @Override 
    public String printDetails(){
        return super.printDetails()+","+salary;
    }
    
}
