package employeeapp;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author room3.03
 */
public class Employee {
    protected String id;
    protected String name;
    protected String dob;
    
    //default constructor
    public Employee(){
        id = "";
        name = "";
        dob = "";
    }
    //overloaded constructor

    public Employee(String id, String name, String dob) {
        this.id = id;
        this.name = name;
        this.dob = dob;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }
    //print details from instantiable to console
    /*public void printDetails(){
        System.out.println("Employee Details:"+id+","+name+","+dob);
    }*/
    //return string to app class for printing there
    public String printDetails(){
        return "Employee Details:"+id+","+name+","+dob;
    }
    
    
    
}
