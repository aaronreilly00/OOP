/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questionapp;

/**
 *
 * @author room3.03
 */
public class EssayQuestion extends Question{
    // Essay questions attributes
    private int maxWordCount;

    // Class constructor with the superclass's attributes passed as parameters
    public EssayQuestion(int maxWordCount, String qText, String cAnswer, double mark, String ans) {
        // use of super() method to invoque the superclass's constructor
        super(qText, cAnswer, mark, ans);
        this.maxWordCount = maxWordCount;
    }
    
    // Getters and Setters for the Question class attributes 
    public int getMaxWordCount() {
        return maxWordCount;
    }

    public void setMaxWordCount(int maxWordCount) {
        this.maxWordCount = maxWordCount;
    }
    
    // PrintDetails method overridden to implement dynamic polymorphism    
    @Override
    public String printDetails(){
        // Use of super.printDetails() to invoque the superclass's printDetails()        
        return super.printDetails()+",Max word Count:"+maxWordCount;
    }
}
