/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questionapp;

/**
 *
 * @author room3.03
 */
public class MCQuestion extends Question{
    // Multiple choice questions attributes
    private String optA;
    private String optB;
    private String optC;

    // Class constructor with the superclass's attributes passed as parameters
    public MCQuestion(String optA, String optB, String optC, String qText, String cAnswer, double mark, String ans) {
        // use of super() method to invoque the superclass's constructor
        super(qText, cAnswer, mark, ans);
        this.optA = optA;
        this.optB = optB;
        this.optC = optC;
    }

    // Getters and Setters for the MCQuestion class attributes 
    public String getOptA() {
        return optA;
    }

    public void setOptA(String optA) {
        this.optA = optA;
    }

    public String getOptB() {
        return optB;
    }

    public void setOptB(String optB) {
        this.optB = optB;
    }

    public String getOptC() {
        return optC;
    }

    public void setOptC(String optC) {
        this.optC = optC;
    }
    
    // PrintDetails method overridden to implement dynamic polymorphism
    @Override
    public String printDetails(){
        // Use of super.printDetails() to invoque the superclass's printDetails()
        return super.printDetails()+",Option A:"+optA+", Option B: "+optB+", Option C:"+optC;
    }
    
    
}
