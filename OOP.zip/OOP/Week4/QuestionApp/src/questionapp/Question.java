/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questionapp;

/**
 *
 * @author room3.03
 */
public class Question {
    // Basic questions attributes
    private String qText;
    private String cAnswer;
    private double mark;
    private String ans;

    // Class constructor
    public Question(String qText, String cAnswer, double mark, String ans) {
        this.qText = qText;
        this.cAnswer = cAnswer;
        this.mark = mark;
        this.ans = ans;
    }

    // Overloaded constructor to implement static polymorphism
    public Question() {
        // use of this() method to invoque the first constructor
        this("", "", 0, "");
    }
    
    // Getters and Setters for the Question class attributes 
    public String getqText() {
        return qText;
    }

    public void setqText(String qText) {
        this.qText = qText;
    }

    public String getcAnswer() {
        return cAnswer;
    }

    public void setcAnswer(String cAnswer) {
        this.cAnswer = cAnswer;
    }

    public double getMark() {
        return mark;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public String getAns() {
        return ans;
    }

    public void setAns(String ans) {
        this.ans = ans;
    }
    
    // PrintDetails method
    public String printDetails(){
        return "Question:"+qText+", Correct: "+cAnswer+",Mark:"+mark+", User Answer:"+ans;
    }
    
    
    
}
