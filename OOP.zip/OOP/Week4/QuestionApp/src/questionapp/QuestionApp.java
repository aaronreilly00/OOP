/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questionapp;

/**
 *
 * @author room3.03
 */
public class QuestionApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create an instance of the superclass by calling the constructor with parameters 
        Question q1 = new Question("Why is the sky blue?", "Because it is", 2, " ");
        System.out.println(q1.printDetails());

        // Create an instance of the superclass Question by calling the constructor without parameters         
        Question q2 = new Question();
        System.out.println(q2.printDetails());
        
        // Create an instance of the subclass MCQuestion
        MCQuestion q3 = new MCQuestion("Because it is", "Its not blue", "Because I said so","Why is the sky blue?", "Because it is", 2, " ");
        System.out.println(q3.printDetails());

        // Create an instance of the subclass EssayQuestion        
        EssayQuestion q4 = new EssayQuestion(2000, "Why is the sky blue?", "Because it is", 2, " ");
        System.out.println(q4.printDetails());
        
    }
    
}
